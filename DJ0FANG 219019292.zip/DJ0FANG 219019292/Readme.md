goodhealthDb
Patient collection
Payment collection
material API
Todo






#######node.js project
initialize npm in the project directory
run through the processes to create package.json file
[] install all the packages we will need for the project
    []express
    []ejs
    []nodemon
    []mongodb