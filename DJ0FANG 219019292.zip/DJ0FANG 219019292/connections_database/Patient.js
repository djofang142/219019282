const mongoose = require('mongoose');

const PatientSchema = new mongoose.Schema({
    first_Name : { type: String, required: true },
    last_Name : { type: String, required: true },
    Date_Of_Birth : { type: Date, default:Date.now },
    contact : { type: String },
    residential_Address : { type: String },
    emergencyNo : { type: String },
})

const Patient = mongoose.model('Patient', PatientSchema);


const PaymentSchema = new mongoose.Schema({
    full_Name : {type: String},
    payment_Date: {type: Date, default: Date.now },
    amount_Paid: {type: Number},
    balance_Amt: {type: Number}
});
const Payment = mongoose.model('Payment', PatientSchema);

module.exports = { Patient, Payment };